#include "question.h"

Question::Question(const int& id, const string& text, const string& answer, const int& score) : id{id}, text{text}, answer{answer}, score{score} { }

