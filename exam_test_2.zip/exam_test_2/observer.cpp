#include "observer.h"

Observer::Observer()
{

}

Observer::~Observer() {}
