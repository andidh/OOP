#include "exception.h"

Exception::Exception(const string& msg) : message{msg} {}

