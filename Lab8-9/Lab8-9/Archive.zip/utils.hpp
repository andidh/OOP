//
//  utils.hpp
//  Lab8-9
//
//  Created by Dehelean Andrei on 4/7/16.
//  Copyright © 2016 Dehelean Andrei. All rights reserved.
//

#pragma once

#include <vector>
#include <string>


using namespace std;

vector<string> tokenize(const string& str, char delimiter);

