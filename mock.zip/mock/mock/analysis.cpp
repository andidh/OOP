//
//  analysis.cpp
//  mock
//
//  Created by Dehelean Andrei on 4/26/16.
//  Copyright © 2016 Dehelean Andrei. All rights reserved.
//

#include "analysis.hpp"
#include <iostream>

void Medical::toString(){
    cout<<"Date: "<<date<<" | ";
}