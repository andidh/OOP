#include "gui.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Repository* repo = new Repository("/Users/AndiD/Documents/C++/exam/prog.txt");
    Controller* ctr = new Controller(repo);
    vector<GUI*> windows;
    for ( auto it : repo->getProgs()){
        GUI* wind = new GUI(ctr, it);
        wind->show();
        repo->addObserver((Observer*) wind);
        windows.push_back(wind);
    }

    int rez = a.exec();

    return rez;
}
