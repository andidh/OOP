#include "controller.h"

Controller::Controller(Repository* repo) : repo{repo}
{

}



void Controller::addFile(const string &fileName, const string &creator) {
    if(fileName == "")
        throw Exception("You must input the file name!");
    for ( auto it : this->getSourceFiles()){
        if ( it.getName() == fileName)
            throw Exception("File already exists!");
    }

    SrcFile s{fileName, "not_revised", creator, "None"};
    this->repo->addFile(s);
}

void Controller::revise(SrcFile &s, const string& name) {
    if( s.getStatus() != "not_revised"){
        throw Exception("Cannot revise this file!");
    }
    if( s.getCreator() == name)
        throw Exception("You cannot revise your own work");

    string fileName = s.getName();
    repo->reviseFile(fileName, name);
}
