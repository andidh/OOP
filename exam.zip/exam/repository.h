#ifndef REPOSITORY_H
#define REPOSITORY_H
#include "subject.h"
#include <vector>
#include "programmer.h"
#include "srcfile.h"
#include <algorithm>
#include <fstream>
#include <sstream>


class Repository : public Subject
{
    vector<Programmer> progs;
    vector<SrcFile> files;
    string file;

public:
    Repository(const string& file);

    vector<Programmer> getProgs() { return this->progs; }
    vector<SrcFile> getSourceFile() { return this->files; }
    void addFile(SrcFile& s) {
        this->files.push_back(s);
        notify(); }

    void removeFile(SrcFile& s);
    void reviseFile(const string& file, const string& name);

private:
    void loadFromFile();
    void writeToFile();
    void sortData();

};




#endif // REPOSITORY_H
