#include "programmer.h"

Programmer::Programmer(const string& name, const int& files) : name{name}, files{files}
{

}


