#ifndef CONTROLLER_H
#define CONTROLLER_H
#include "repository.h"
#include "exception.h"

class Controller
{
    Repository* repo;
public:
    Controller(Repository* repo);

    vector<Programmer> getProgrammers() { return repo->getProgs(); }
    vector<SrcFile> getSourceFiles() { return repo->getSourceFile(); }
    void addFile(const string& fileName, const string& creator);
    void removeFile(SrcFile& s) { this->repo->removeFile(s); }
    void revise(SrcFile& s, const string& name);

};

#endif // CONTROLLER_H
