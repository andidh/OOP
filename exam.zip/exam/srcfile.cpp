#include "srcfile.h"

SrcFile::SrcFile(const string& name, const string& status, const string& creator,  const string& reviewer) :
    name{name}, status{status}, creator{creator}, reviewer{reviewer}
{

}
