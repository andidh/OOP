#include "exception.h"

Exception::Exception(const string& message) : message{message}
{

}
